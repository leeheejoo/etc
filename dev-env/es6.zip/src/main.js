
const str = `es6`;

console.log(`javascript ${str}`);

let arr = [1,2,3,4,5];
arr.forEach(el => {
    console.log(el);
})


console.log(arr);
console.log(...arr);

import { sum } from './m1';
//const sum = require('./m1').sum;
console.log(sum(111,11233))
console.log('끝1123');